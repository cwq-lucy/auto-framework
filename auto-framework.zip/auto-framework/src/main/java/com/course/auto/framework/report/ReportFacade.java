package com.course.auto.framework.report;

public class ReportFacade {
}
