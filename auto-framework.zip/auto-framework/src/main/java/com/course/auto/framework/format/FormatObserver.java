package com.course.auto.framework.format;

import java.lang.reflect.Method;

public interface FormatObserver {

    void format(Method testMethod);
}
