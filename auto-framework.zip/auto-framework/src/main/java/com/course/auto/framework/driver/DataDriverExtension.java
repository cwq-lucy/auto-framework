package com.course.auto.framework.driver;

import com.course.auto.framework.annotation.DataDriver;
import com.course.auto.framework.annotation.DataParam;
import com.course.auto.framework.model.DataEntity;
import com.course.auto.framework.util.YmlUtils;
import com.google.common.collect.Lists;
import com.google.gson.Gson;

import org.junit.jupiter.api.extension.*;
import org.junit.platform.commons.support.AnnotationSupport;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.List;
import java.util.stream.Stream;

public class DataDriverExtension implements TestTemplateInvocationContextProvider {


    @Override
    public boolean supportsTestTemplate(ExtensionContext context) {
        return context.getTestMethod()
                .filter(method -> AnnotationSupport.isAnnotated(method, DataDriver.class))
                .isPresent();
    }

    @Override
    public Stream<TestTemplateInvocationContext> provideTestTemplateInvocationContexts(ExtensionContext context) {
        Method testMethod = context.getRequiredTestMethod();
        DataDriver dataDriver = testMethod.getAnnotation(DataDriver.class);
        List<DataEntity> dataEntities = YmlUtils.read(dataDriver.path());
        return dataEntities.stream().map(DataDriverExtension2.DataInvocationContext::new);
    }

    static class DataInvocationContext implements TestTemplateInvocationContext, ParameterResolver {
        private DataEntity dataEntity;

        public DataInvocationContext (DataEntity dataEntity){
            this.dataEntity=dataEntity;
        }
        @Override
        public boolean supportsParameter(ParameterContext parameterContext, ExtensionContext extensionContext) throws ParameterResolutionException {
            return extensionContext.getTestMethod()
                    .filter(method -> AnnotationSupport.isAnnotated(method, DataDriver.class))
                    .isPresent();
        }

        @Override
        public Object resolveParameter(ParameterContext parameterContext, ExtensionContext extensionContext) throws ParameterResolutionException {
            Parameter parameter = parameterContext.getParameter();
            DataParam dataParam = parameter.getAnnotation(DataParam.class);
            if (dataEntity.isKeyExists(dataParam.value())) {
                // 就是我们需要去做数据设置的
                DataEntity.Entity entity = dataEntity.getEntity(dataParam.value());

                if (entity.isJavaBean()) {
                    return new Gson().fromJson(entity.getVal(), parameter.getType());
                }

                return parseToJavaType(entity.getVal(), parameter.getType());

            }
            throw new IllegalStateException("none type");
        }

        private Object parseToJavaType(String val, Class<?> type) {
            switch (type.getName()) {
                case "java.lang.Integer":
                    return Integer.valueOf(val);
                case "java.lang.Long":
                    return Long.valueOf(val);
                case "java.lang.Boolean":
                    return Boolean.valueOf(val);
                case "java.lang.String":
                    return val;
                default:
                    throw new IllegalArgumentException("have not support type=" + type.getName());
            }
        }
        @Override
        public String getDisplayName(int invocationIndex) {
            return "data driver:" + invocationIndex;
        }

        @Override
        public List<Extension> getAdditionalExtensions() {

            return Lists.newArrayList(this);
        }

    }

}
