package com.course.auto.framework.model;


public enum ReportType {

    DING_TALK,
    HTML,

    
}
