package com.course.auto.framework.model;

public interface TokenConst {

    String DEFAULT="70d088f5669bd54f7f4a183a5d28e9973eab2111f572b39e8d286c2550d4ff54";

}
