package com.course.auto.framework.report.callback;

import com.course.auto.framework.model.SummaryResult;

public interface ReportCallback {

    void postExecutionSummary(SummaryResult summaryResult);

}
