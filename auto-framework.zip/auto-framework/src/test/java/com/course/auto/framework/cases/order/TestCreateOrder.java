package com.course.auto.framework.cases.order;

import com.course.auto.framework.annotation.*;
import okhttp3.*;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;

public class TestCreateOrder {
    //  @AutoTest
    @CaseTitle("1111")
    @CaseDesc(desc = "1111", owner = "1111")
    @CheckPoint("1111")
    @CaseTag(key = "project", val = "meituan")
    @CaseTag(key = "module", val = "order")
    @CaseTag(key = "level", val = "redline")
    @DataDriver(path = "data\\demo1.yml")
    public void testNew2(@DataParam("url") String url) {
        String URL = url.replace("\"", "");

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(URL)
                .addHeader("Accept", "*/*")
                .addHeader("vvToken", "7b93dcf5a196d091ecbd7e8061943824")
                .get()  //默认为GET请求，可以不写
                .build();
        final Call call = client.newCall(request);
        try {
            Response response = call.execute();
            ResponseBody responseBody = response.body();
            System.out.println("responseBody.string() = " + responseBody.string());
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
        Assertions.assertEquals("code","4040");
    }

    //  @AutoTest
    @CaseTitle("1111")
    @CaseDesc(desc = "1111", owner = "1111")
    @CheckPoint("1111")
    @CaseTag(key = "project", val = "meituan")
    @CaseTag(key = "module", val = "order")
    @CaseTag(key = "level", val = "redline")
    @DataDriver(path = "data/demo1.yml")
    public void testNew22(@DataParam("url") String url,@DataParam("jsonStr") String jsonStr) {
        String URL = url.replace("\"", "");
        MediaType JSON = MediaType.parse("application/json;charset=UTF-8; charset=utf-8");

        RequestBody body = RequestBody.create(JSON, jsonStr);
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(URL)
                .addHeader("Content-Type","application/json")
                .addHeader("vvToken", "7b93dcf5a196d091ecbd7e8061943824")
                .post(body)
                .build();

        final Call call = client.newCall(request);
        try {
            Response response = call.execute();
            ResponseBody responseBody = response.body();
            System.out.println("responseBody.string() = " + responseBody.string());
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }
}
