package com.course.auto.framework;


import org.junit.jupiter.api.Test;

public class App {
//    private static final int STRING_BUILDER_SIZE = 256;
//    public static final String SPACE = " ";
//    public static final String EMPTY = "";
//    public static final String LF = "\n";
//    public static final String CR = "\r";
//    public static final int INDEX_NOT_FOUND = -1;
//    private static final int PAD_LIMIT = 8192;
//
//    @Test
//    public static String addreviate(String str, int maxWidth) {
//        return addreviate("str", 1024);
//
//    }


}
